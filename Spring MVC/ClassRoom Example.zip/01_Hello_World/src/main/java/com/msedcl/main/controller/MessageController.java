package com.msedcl.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MessageController {

	@GetMapping("exchange")
	public String showMessagePage() {
		return "message";
	}

	@PostMapping("postmessage")
	public String getMessage(String txtmessage, Model model) {
		model.addAttribute("msg", txtmessage);
		log.info("Message reveived from client :: " + txtmessage);
		return "showmessage";
	}
}
