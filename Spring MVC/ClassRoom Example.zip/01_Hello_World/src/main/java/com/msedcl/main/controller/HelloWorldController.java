package com.msedcl.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HelloWorldController {
	public HelloWorldController() {
		log.info("HelloWorldController object created");
	}
	

	@GetMapping("next")
	public String showNextPage() {
		log.info("showNextPage() called");
		return "second";
	}
	
	@GetMapping("/")
	public String showWelcomePage() {
		log.info("showWelcomePage() called");
		return "greet";
	}
}
