package com.msedcl.main.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.msedcl.main.dto.EmployeeRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class EmployeeController {

	
	@GetMapping("printall")
	public String printAllEmployees(Model model) {
		EmployeeRequestDTO employeeRequestDTO1 = new EmployeeRequestDTO("Laxman", "J", 900000);
		EmployeeRequestDTO employeeRequestDTO2 = new EmployeeRequestDTO("Rajendra", "B", 900000);
		EmployeeRequestDTO employeeRequestDTO3 = new EmployeeRequestDTO("Badrinath", "F", 900000);

		List<EmployeeRequestDTO> employeesList = Arrays.asList(employeeRequestDTO1, employeeRequestDTO2,
				employeeRequestDTO3);
		
		model.addAttribute("allemployees", employeesList);
		return "showallemployees";
	}

	@GetMapping("newemployee")
	public String showCreateEmployeePage(Model model) {
		EmployeeRequestDTO employeeRequestDTO = new EmployeeRequestDTO();
		model.addAttribute("employeeRequestDTO", employeeRequestDTO);
		return "employee";
	}

	@PostMapping("storeemployee")
	public String saveEmployee( EmployeeRequestDTO employeeRequestDTO) {
		log.info("Employee Reveived :: " + employeeRequestDTO.toString());
		return "greet";
	}
}
