<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Application</title>
</head>
<body>
	<h2>Welcome to Spring MVC - JSP</h2>
	<hr>
	<h2>All Employees</h2>
	<hr>
	<c:forEach var="c" items="${allemployees}">
		${c.firstName}
		<br>
		${c.lastName}
		<br>
		${c.salary }
		<br>
		<br>
	</c:forEach>
</body>
</html>