<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="f"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Application</title>
</head>
<body>
	<f:form action="storeemployee" modelAttribute="employeeRequestDTO">
		First Name <f:input path="firstName"/>
		<br>
		Last Name <f:input path="lastName"/>
		<br>
		Salary <f:input path="salary"/>
		<input type="submit" value="Save"> 
	</f:form>
</body>
</html>