package com.msedcl.main.customer.service;

import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.msedcl.main.customer.common.ApiResponse;
import com.msedcl.main.customer.dto.CustomerResponseDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomerAPIService {

	private final RestTemplate restTemplate;

	public List<CustomerResponseDTO> getAllCustomers() {
		String url = "http://localhost:8181/customersapi/customers";

		ResponseEntity<ApiResponse<List<CustomerResponseDTO>>> response = restTemplate.exchange(url, HttpMethod.GET,
				null, new ParameterizedTypeReference<ApiResponse<List<CustomerResponseDTO>>>() {

				});

		return response.getBody().getData();

	}
}
