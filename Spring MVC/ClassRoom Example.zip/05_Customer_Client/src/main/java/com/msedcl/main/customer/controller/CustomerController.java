package com.msedcl.main.customer.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.msedcl.main.customer.dto.CustomerResponseDTO;
import com.msedcl.main.customer.service.CustomerAPIService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
@Controller
public class CustomerController {

	private final CustomerAPIService customerAPIService;
	
	// GET = http://localhost:8080/customers ----> customer-list.html
	@GetMapping("/customers")
	public String getAllCustomers(Model model) {
		List<CustomerResponseDTO> customerResponseDTOList = customerAPIService.getAllCustomers();
		model.addAttribute("customers", customerResponseDTOList);
		return "customer-list";
	}
}
