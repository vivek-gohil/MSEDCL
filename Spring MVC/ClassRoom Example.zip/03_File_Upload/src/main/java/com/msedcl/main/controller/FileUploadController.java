package com.msedcl.main.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import com.msedcl.main.dto.FileUploadDTO;
import com.msedcl.main.service.FileUploadService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class FileUploadController {

	@Value("${file.upload-dir}")
	private String location;

	// http://localhost:8080/upload-file
	@GetMapping("upload-file")
	public String showUploadPage(Model model) {
		FileUploadDTO fileUploadDTO = new FileUploadDTO();
		model.addAttribute("fileUploadDTO", fileUploadDTO);
		return "upload";
	}

	@PostMapping("upload")
	public String uploadFile(@ModelAttribute FileUploadDTO fileUploadDTO, Model model) {
		MultipartFile file = fileUploadDTO.getFile();

		if (file.isEmpty()) {
			model.addAttribute("message", "Invalid File !!");
		} else {
			String fileName = file.getOriginalFilename();
			File destination = new File(location + fileName);
			try {
				file.transferTo(destination);
				model.addAttribute("message", "File uploaded successfully!!");
			} catch (IllegalStateException | IOException e) {
				log.info(e.getMessage());
				model.addAttribute("message", "Upload Failed !!");
			}
		}

		return "upload";
	}
}
