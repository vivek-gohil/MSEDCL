package com.msedcl.main.dto;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadDTO {
	private MultipartFile file;

	public FileUploadDTO() {
		System.out.println("FileUploadDTO object created!!");
	}

	public MultipartFile getFile() {
		System.out.println("getFile() called");
		return file;
	}

	public void setFile(MultipartFile file) {
		System.out.println("setFile() called");
		this.file = file;
	}

}
