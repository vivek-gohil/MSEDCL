package com.msedcl.main.service;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.msedcl.main.Application;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileUploadService {

	private final Application application;

	FileUploadService(Application application) {
		this.application = application;
	}

	public int uploadFile(MultipartFile file) {
		if (file.isEmpty()) {
			log.info("File is empty");
			return 0;
		} else {
			log.info("Upload started");
			String fileName = file.getOriginalFilename();
			File destination = new File("c:/uploads/" + fileName);
			try {
				file.transferTo(destination);
				log.info("uploaded !!");
				return 1;
			} catch (IllegalStateException | IOException e) {
				log.info("Exception");
				log.info(e.getMessage());
				return -1;
			}
		}
	}
}
