function validateForm() {
	const fileInput = document.getElementById("file");
	if(!fileInput.value) {
		alert("Please select file");
		return false;
	}
	return true;
}