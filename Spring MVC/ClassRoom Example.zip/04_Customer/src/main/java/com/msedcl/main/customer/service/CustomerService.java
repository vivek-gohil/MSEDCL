package com.msedcl.main.customer.service;

import java.util.List;

import com.msedcl.main.customer.dto.CustomerRequestDTO;
import com.msedcl.main.customer.dto.CustomerResponseDTO;
import com.msedcl.main.customer.dto.UpdateCustomerRequestDTO;

public interface CustomerService {

	CustomerResponseDTO createCustomer(CustomerRequestDTO customerRequestDTO);

	CustomerResponseDTO getCustomerById(Integer id);

	List<CustomerResponseDTO> getAllCustomers();

	CustomerResponseDTO getCustoemrByEmail(String email);

	CustomerResponseDTO updateCustomer(UpdateCustomerRequestDTO customerRequestDTO);

}
