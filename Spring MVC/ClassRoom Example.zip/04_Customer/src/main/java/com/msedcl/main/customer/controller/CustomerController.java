package com.msedcl.main.customer.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.msedcl.main.customer.dto.CustomerRequestDTO;
import com.msedcl.main.customer.dto.CustomerResponseDTO;
import com.msedcl.main.customer.dto.UpdateCustomerRequestDTO;
import com.msedcl.main.customer.service.CustomerService;
import com.msedcl.main.customer.service.CustomerServiceImpl;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@AllArgsConstructor
public class CustomerController {

	private final CustomerService customerService;

	// GET = http://localhost:8080/customers/update/{id} ----> customer-update.html
	@GetMapping("/customers/update/{customerId}")
	public String showUpdateCustomerPage(@PathVariable int customerId, Model model) {
		CustomerResponseDTO customerResponseDTO = customerService.getCustomerById(customerId);

		UpdateCustomerRequestDTO updateCustomerRequestDTO = new UpdateCustomerRequestDTO(
				customerResponseDTO.getCustomerId(), customerResponseDTO.getName(), customerResponseDTO.getEmail(),
				customerResponseDTO.getMobileNumber());
		model.addAttribute("updateCustomerRequestDTO", updateCustomerRequestDTO);
		return "customer-update";
	}

	// GET = http://localhost:8080/customers/{id} -----> customer-view.html
	@GetMapping("customers/{customerId}")
	public String showCustomerDetails(@PathVariable int customerId, Model model) {
		CustomerResponseDTO customerResponseDTO = customerService.getCustomerById(customerId);
		model.addAttribute("customerResponseDTO", customerResponseDTO);
		return "customer-view";
	}

	@PostMapping("/customers/update")
	public String updateCustomer(UpdateCustomerRequestDTO customerRequestDTO) {
		customerService.updateCustomer(customerRequestDTO);
		return "redirect:/customers";
	}

	// POST = http://localhost:8080/customers ----> customer-list.html
	@PostMapping("/customers")
	public String addNewCustomer(@Valid CustomerRequestDTO customerRequestDTO, BindingResult result) {
		if (result.hasErrors()) {
			return "customer-form";
		}
		customerService.createCustomer(customerRequestDTO);
		return "redirect:/customers";
	}

	// GET = http://localhost:8080/customers/new ----> customer-form.html
	@GetMapping("/customers/new")
	public String showAddNewCustomerForm(Model model) {
		CustomerRequestDTO customerRequestDTO = new CustomerRequestDTO();
		model.addAttribute("customerRequestDTO", customerRequestDTO);
		return "customer-form";
	}

	// GET = http://localhost:8080/customers ----> customer-list.html
	@GetMapping("/customers")
	public String getAllCustomers(Model model) {
		List<CustomerResponseDTO> customerResponseDTOList = customerService.getAllCustomers();
		model.addAttribute("customers", customerResponseDTOList);
		return "customer-list";
	}
}
