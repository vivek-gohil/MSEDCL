package com.msedcl.main.customer.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateCustomerRequestDTO {
	private Integer customerId;
	private String name;
	private String email;
	private String mobileNumber;
}
