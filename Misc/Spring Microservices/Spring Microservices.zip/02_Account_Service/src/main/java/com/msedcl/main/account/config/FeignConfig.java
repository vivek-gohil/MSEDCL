package com.msedcl.main.account.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import feign.RequestInterceptor;
import jakarta.servlet.http.HttpServletRequest;

@Configuration
public class FeignConfig {

	@Bean
	RequestInterceptor requestInterceptor() {
		return requestTemplate -> {

			ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

			if (attr != null) {
				HttpServletRequest request = attr.getRequest();
				String token = request.getHeader("Authorization");

				if (token != null) {
					requestTemplate.header("Authorization", token);
				}
			}
		};
	}
}
