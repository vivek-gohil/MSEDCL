package com.msedcl.main.account.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.msedcl.main.account.common.ApiResponse;
import com.msedcl.main.account.dto.CustomerResponseDTO;

@FeignClient(name = "customer", path = "/customersapi", fallback = CustomerServiceFallback.class)
public interface CustomerServiceFeignClient {

	@GetMapping("/customers/customer/{customerId}")
	ResponseEntity<ApiResponse<CustomerResponseDTO>> getCustomerByCustomerId(@PathVariable int customerId);
}
