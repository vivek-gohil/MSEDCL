package com.msedcl.main.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing(auditorAwareRef = "auditAwareImpl")
@SpringBootApplication
@EnableFeignClients
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}


//1. Client → Account Service
//		Authorization: Bearer TOKEN
//
//2. JwtAuthFilter:
//		→ Validate token
//		→ Set authentication
//
//3. Account Controller executes
//
//4. Feign Call → Customer
//		→ FeignConfig adds token
//
//5. Customer Service:
//		→ JwtAuthFilter validates token
//
//6. Response returned