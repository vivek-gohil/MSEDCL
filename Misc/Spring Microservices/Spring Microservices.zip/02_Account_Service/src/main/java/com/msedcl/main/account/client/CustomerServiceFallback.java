package com.msedcl.main.account.client;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.msedcl.main.account.common.ApiResponse;
import com.msedcl.main.account.dto.CustomerResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomerServiceFallback implements CustomerServiceFeignClient {
	@Override
	public ResponseEntity<ApiResponse<CustomerResponseDTO>> getCustomerByCustomerId(int customerId) {
		log.info("fallback invoked!!");
		return null;
	}
}
